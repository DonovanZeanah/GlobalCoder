using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace Aga.Controls.Tree
{
	/*internal class ColumnCollection: Collection<Column>
	{
		public int TotalWidth
		{
			get
			{
				int res = 0;
				foreach (Column c in Items)
					res += c.Width;
				return res;
			}
		}
	}*/
}
