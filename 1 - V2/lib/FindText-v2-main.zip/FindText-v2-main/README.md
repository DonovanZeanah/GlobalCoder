# FindText-v2
FindText library port to AHK v2

Current status: alpha stage, very buggy and barely functional
