double __main(double A, double B) {
    return (A + B) * 2.2;
}