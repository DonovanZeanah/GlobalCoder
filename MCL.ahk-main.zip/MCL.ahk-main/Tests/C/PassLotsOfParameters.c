int __main(int A, int B, int C, int D, int E) {
    return A + B + C + D + E;
}