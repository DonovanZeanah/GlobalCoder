int TheOnlyFunctionInThisProgram(int left, int right) {
    return left << right;
}