int __main() {
    return 2390;
}