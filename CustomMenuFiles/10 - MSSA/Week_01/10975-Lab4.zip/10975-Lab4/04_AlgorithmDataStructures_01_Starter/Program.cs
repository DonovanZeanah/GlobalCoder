﻿using Microsoft.Extensions.Configuration;
using System.Collections;

namespace _04_AlgorithmDataStructures_01_Starter
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Console.WriteLine("04 -> Algorithms and Data Structures");

            // #TODO: Task 1.2 Create an array here called gradesArray


            // #TODO: Task 1.3 Call the addGrades method, passing it the gradesArray


            // #TODO: Task 1.4 After adding grades to the array, call the displayGrades method
            // to print out the grades to the console window
            // Use the foreach construct to iterate over the array


            // #TODO: Task 2.1 Create a new Stack object called myStack


            // #TODO: Task 2.2 Call the pushStack() method passing in the grades array for values

            // #TODO: Task 2.3 Call the peekStack() method passing in the grades array for values

            // #TODO: Task 2.4 Call the popStack() method twice to remove the top two items from stack
            // The popStack method will display each popped item to the console window


            // #TODO: Task 3.1 Create a new SortedList object called myCourses




            // #TODO: Task 3.2 Call the populateList() method




            // #TODO: Task 3.3 display a course in the list by passing a key




            // #TODO: Task 3.4 Remove an item from the myCourses list using the key

        }


        static void addGrades(float[] grdArray)
        {

        }

        static void displayGrades(float[] grdArray)
        {

        }


        static void pushStack(float[] grdArray)
        {

        }

        static void popStack(Stack stack)
        {
            Console.WriteLine("Item removed from the stack: ");

        }

        static void populateList(SortedList list)
        {

        }

        static void displayList(SortedList list, string filter)
        {

        }

        static void removeListItem(SortedList list, string filter)
        {

        }
    }
}
