This repo contains the libraries I use

Most of them are mine, but some will be libraries of other people

Not because I'm a fiend for stealing, but because it's simply easier for me to manage

## People to check out for cool libraries:

* [**@thqby**](https://github.com/thqby)
* [**@Descolada**](https://github.com/Descolada)

## Dependencies

The libraries will generally list all of their dependencies at the top by

```
#Include <this-library>
```

All the libraries I use will be in this repository, so you can *technically* use any / all of my / not my libraries
