output.ReadOnly = true
output:LineScroll(-1000, 0)