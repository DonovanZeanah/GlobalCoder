using System;

class newprogram {
	static void Main(){
		Console.WriteLine("hola");
		var theo = Console.ReadLine();
		Console.WriteLine(theo);
		var 

	}
}